# FAQ für die KI

Platzhalter. Hier gehören kurze Markdown-Dokumente hinein, die der Coding-Agent vor der Arbeit liest, z. B.:

- Namenskonventionen und Paketstruktur
- Transportwesen und Freigabeprozess
- Häufige Fehlermeldungen und ihre Lösung
- Welche sapcli-Befehle erlaubt sind

Eine Datei pro Thema, Dateiname beschreibt das Thema.
